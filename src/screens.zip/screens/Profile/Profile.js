import React, { useState, useEffect } from 'react';
import axios from 'axios'
import { View, StyleSheet, Text, Image, Pressable, FlatList, SafeAreaView, Alert, ActivityIndicator } from 'react-native';
import { mainColors } from '../../colors/color-map';
// import Dropdown from '../Components/Dropdown';
import Icon from 'react-native-vector-icons/FontAwesome';
import Frame from "../../assets/icons/Frame.svg";
import AsyncStorage from '@react-native-async-storage/async-storage'

const Profile = ({ route, navigation }) => {


  const [username, setusername] = useState('')
  const [userId, setuserId] = useState('')
  const [email,setEmail]=useState('')


  useEffect(() => {

    setValues()

  }, [])

  const logout = async () => {
    await AsyncStorage.clear()
    navigation.navigate('Login')
  }



  const setValues = async () => {
    let uname = await AsyncStorage.getItem('Username')
    let uid = await AsyncStorage.getItem('userId')
    let email=await AsyncStorage.getItem('email')
    await setusername(uname)
    await setuserId(uid)
    await setEmail(email)
  }




  return (
    <View style={styles.container}>
      {
        Platform.OS === 'ios' &&
        <View style={{ marginTop: 50, }}>
        </View>
      }
      <View style={{marginLeft:10}}>
        <Pressable onPress={() => { navigation.goBack(); }}>
          <Text style={styles.titleText} ><Icon size={30} name='angle-left' /></Text>
        </Pressable>
      </View>

      <View style={{ alignItems: "center", marginTop: 50 }}>
        <View style={{ backgroundColor: "#D1A6E7", padding: 20, borderRadius: 50 }}>
          < Image style={styles.cancel}
            source={require("../../assets/icons/camera.png")}
          />
        </View>
      </View>

      <View style={{ alignItems: "center", marginTop: 30 }}>
        <Text style={styles.heading}>{username}</Text>
      </View>

      <View style={{ alignItems: "center", marginTop: 10 }}>
        <Text style={{fontSize:13}}>{email}</Text>
      </View>

      

      <Pressable style={styles.buttonvw} onPress={logout}>
        <Text allowFontScaling={false} style={styles.textApple}>
          Logout
        </Text>
      </Pressable>



    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    margin: 20,
    // marginTop: Platform.OS === 'ios' && 50,
    flex: 1,
  },
  heading: {
    fontWeight: '600',
    fontSize: 50,
    color: "black"
  },
  buttonvw: {
    width: 328,
    height: 44,
    top: 190,
    backgroundColor: "#702963",
    borderRadius: 12,
    alignSelf: "center",
    borderWidth: 2.6,
    borderColor: "#F6F8FB",

  },
  textApple: {
    fontFamily: "Inter-Regular",
    fontWeight: "600",
    fontSize: 14,
    top: 11,
    color: "#fff",
    justifyContent: "center",
    textAlign: "center",
  },
})

export default Profile;