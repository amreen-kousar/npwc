import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  Button,
  View,
  SafeAreaView,
  Text,
  Alert,
  TextInput,
  Pressable,
  ActivityIndicator
} from 'react-native';
import Logo from '../../assets/icons/Frame.svg';
import axios from 'axios'
import AsyncStorage from '@react-native-async-storage/async-storage'

const Login = ({ navigation }) => {

  const [response, setResponse] = useState()
  const [loginStatus, setLoginStatus] = useState('Login')
  const [formValue, setFormValue] = useState({ email_id: "", password: "" })


  useEffect(() => {
    AsyncStorage.clear()
    setFormValue({ email_id: "", password: "" })
    setLoginStatus("Login")
  }, [])


  const loginUser = () => {
    console.log('login', formValue)
    if (formValue.email_id == '' || formValue.password == '') {
      Alert.alert('Fill all the fields')
    }
    else {
      axios.post(`https://aipse.in/api/login`, formValue)
        .then(function (response) {
          setLoginStatus('Signing In please wait ! ')
          console.log(response?.data, "responseeeeeee")
          if (response?.data?.Status) {
            console.log(response?.data?.Username)
            response.data['User ID'] = response?.data['User ID'].toString()
            AsyncStorage.setItem('Username', response?.data?.Username)
            AsyncStorage.setItem('email', formValue.email_id)
            AsyncStorage.setItem('token', response?.data?.Token)
            AsyncStorage.setItem('userId', response?.data['User ID'])
            navigation.navigate('HomeScreen')
            setFormValue({ email_id: "", password: "" })
          }
          else {
            Alert.alert('Invalid mail or password')
          
            setLoginStatus('Login')
            // setResponse(response?.data?.Message)
          }
        })
        .catch(function (error) {

          Alert.alert("Backend issue\n" +
            error);
          console.log(error);
        });
    }
  }
  return (

    <SafeAreaView style={styles.container}>

      <View>

        <View style={styles.logovw}>
          <Logo style={styles.logop} />
        </View>

        <View flexDirection={'column'}>
          <TextInput
            style={styles.input}
            placeholderTextColor="#8E9AA7"
            placeholder="Email ID"
            keyboardType="default"
            onChangeText={(e) => { setFormValue({ ...formValue, email_id: e }); setLoginStatus('Login') }}
          />
          <TextInput
            style={styles.input}
            placeholderTextColor="#8E9AA7"
            placeholder="Password"
            keyboardType="default"
            onChangeText={(e) => { setFormValue({ ...formValue, password: e }); setLoginStatus('Login') }}
          />
        </View>

        {/* <View style={{ alignItems: "center", top: -10, fontWeight: 700, color: 'red' }}>

          <Text >{response}</Text>
        </View> */}

        <Pressable style={styles.buttonvw} onPress={loginUser}>
          <Text allowFontScaling={false} style={styles.textApple}>
            {loginStatus}
          </Text>
        </Pressable>


        <Pressable style={{ top: 120, }} onPress={() => { navigation.navigate('Register') }}>
          <View style={{ alignSelf: "center", padding: 6, borderRadius: 10 }}>
            <Text style={{ fontSize: 20 }}> Create an account .</Text>
          </View>
        </Pressable>

      </View>

    </SafeAreaView>
  )
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: "#fff"
  },
  logovw: {
    alignItems: 'center',
    marginBottom: 40
  },
  input: {
    height: 40,
    margin: 12,
    borderWidth: 1,
    padding: 10,
    borderRadius: 8,
    top: '-16%',
    color: '#112866',
    borderColor: "#C8CEDD",
    fontFamily: "Inter-Regular",
    fontSize: 14,
    backgroundColor: '#fff'
  },
  buttonvw: {
    width: 328,
    height: 44,
    // top: 50,
    backgroundColor: "#702963",
    borderRadius: 12,
    alignSelf: "center",
    borderWidth: 2.6,
    borderColor: "#F6F8FB",
  },
  textApple: {
    fontFamily: "Inter-Regular",
    fontWeight: "600",
    fontSize: 14,
    top: 11,
    color: "#fff",
    justifyContent: "center",
    textAlign: "center",
  },
});

export default Login;