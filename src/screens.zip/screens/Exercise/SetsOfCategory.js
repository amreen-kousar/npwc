import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Text, StyleSheet, Platform, View, Image, Button, Pressable, FlatList, RefreshControl, Dimensions, Alert, ActivityIndicator } from 'react-native';
import axios from 'axios';
import { mainColors } from '../../colors/color-map';
import LightCard from '../Components/LightCard';
import Icon from 'react-native-vector-icons/FontAwesome';
import { BottomSheetScrollView, BottomSheetBackdrop, BottomSheetModal, BottomSheetModalProvider } from "@gorhom/bottom-sheet";
import DetailItem from '../Components/DetailItem';
import AsyncStorage from '@react-native-async-storage/async-storage'
import { useIsFocused } from "@react-navigation/native";


const SetsOfCategory = ({ route, navigation }) => {

    const [items, setItems] = useState([])
    const [itemIntakeStatus, setItemIntakeStatus] = useState([])
    const [refreshing, setRefreshing] = useState(false)
    const [page, setPage] = useState(1)
    const [selectedData, setSelectedData] = useState(null)
    const [categoryName, setCategoryName] = useState(null)
    const snapPoints = ['39%'];
    const bottomSheetModalRef = useRef(null);
    const windowHeight = Dimensions.get('window').height;
    const [loading, setLoading] = useState(true)
    const [addServings, setAddServings] = useState(0)
    const isFocused = useIsFocused();

    // console.log(route?.params, "royre paramsss")

    useEffect(() => {
        if (isFocused) {
            apiCall()
        }
    }, [isFocused])

    const apiCall = async () => {
        let userIdAsync = await AsyncStorage.getItem('userId')

        setCategoryName(route?.params.category)

        axios.get(`https://aipse.in/api/getItemsOfCategory?category_id=${route?.params.cat}&type=exercise`)
            .then(function (response) {
                setItems(response?.data?.data)
                axios.get(`https://aipse.in/api/itemIntakeStatus?userid=${userIdAsync}&type=exercise&category=${route?.params.category}`)
                    .then(function (response) {
                        console.log(response?.data)
                        setItemIntakeStatus(response?.data?.data)
                        setLoading(false)
                    })
                    .catch(function (error) {
                        // Alert.alert("something went wrong");
                        // console.log(error);
                    });
            })
            .catch(function (error) {
                // Alert.alert("something went wrong");
                // console.log(error);
            });
    }


    const getStatus = (id) => {
        // console.log(itemIntakeStatus, id)
        let servings = itemIntakeStatus?.filter(i => i?.item_id == id)
        return servings?.length > 0 ? servings[0].servings_consumed : 0
    }



    const handleSnapPress = useCallback((item) => {
        setSelectedData({ ...item, ...route.params });
        bottomSheetModalRef.current?.present();
    }, []);

    const closeBackdrop = (servings, item) => {
        Alert.alert(`You have done ${servings} sets of ${item.item_name}`)
        setAddServings(servings)
        apiCall()
        bottomSheetModalRef.current?.close();
    }

    const renderBackdrop = useCallback(
        props => (
            <BottomSheetBackdrop
                {...props}
                opacity={2.5}
                disappearsOnIndex={-1}
                pressBehavior={() => {
                    Alert.alert("qwewqe")
                }}
                appearsOnIndex={2}
            />
        ),
        []
    );

    return (
        <View style={styles.container}>
            {
                Platform.OS === 'ios' &&
                <View style={{ marginTop: 50, }}>
                </View>
            }
            <Pressable onPress={() => { route?.params?.apiCall(); navigation.goBack(); }}>
                <Text style={styles.titleText} ><Icon size={30} name='angle-left' /></Text>
            </Pressable>
            <View style={{ flexDirection: "row", marginTop: 10, marginLeft: 10 }}>
                <View style={{ flex: 1, marginTop: 10 }}>
                    <Text style={styles.heading}>{categoryName}</Text>
                    <Text style={styles.text}>45 calories / set</Text>
                    <Text style={{ color: "black" }}>13 sets / day</Text>

                </View>
                <View style={[styles.card, styles.goldCard]}>
                    <Text style={styles.num}>{route?.params?.servingsConsumed + addServings}</Text>
                    <Text style={{ color: "black" }} >sets</Text>
                    <Text style={{ color: "black" }}>done</Text>
                </View>

            </View>

            <FlatList
                showsVerticalScrollIndicator={false}
                showsHorizontalScrollIndicator={false}
                // refreshControl={
                //     <RefreshControl
                //         refreshing={refreshing}
                //         onRefresh={() => { setRefreshing(!refreshing) }}
                //     />
                // }
                data={items}
                // onEndReached={() => {
                //     setPage(page + 1);
                // }}
                ListEmptyComponent={() => {
                    return (
                        <View style={{ flex: 1, alignItems: "center", justifyContent: "center", marginTop: 100 }}>{loading ? <View ><Text> <ActivityIndicator color="#1b1c1e" /></Text></View> : <Text>No exercises found</Text>}</View>
                    )
                }}
                keyExtractor={(item) => item.item_id}
                renderItem={({ item }) => (
                    <Pressable onPress={() => { handleSnapPress(item) }}>
                        <LightCard item={item} servings={getStatus(item.item_id)} />
                    </Pressable>
                )}
            />



            <BottomSheetModalProvider>
                <BottomSheetModal
                    backdropComponent={renderBackdrop}
                    animateOnMount={false}
                    ref={bottomSheetModalRef}
                    index={0}
                    snapPoints={snapPoints}
                    enablePanDownToClose={true}
                >
                    <BottomSheetScrollView
                        scrollEnabled={windowHeight > 800 ? false : true}
                    >
                        {selectedData ? (
                            <DetailItem item={selectedData} closeBackdrop={closeBackdrop} servings={getStatus(selectedData.item_id)} />
                        ) : <Text>no data found</Text>}
                    </BottomSheetScrollView>
                </BottomSheetModal>

            </BottomSheetModalProvider>

        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        padding: 20,
        // marginTop: Platform.OS === 'ios' && 50,
        flex: 1,
    },
    heading: {
        fontSize: 22,
        marginBottom: 10,
        color: "black"

    },
    text: {
        marginBottom: 10,
        color: "black"
    },
    num: {
        color: "black",
        fontSize: 30,
        fontWeight: '600'
    },
    shadowProp: {
        elevation: 3,
        shadowColor: '#171717',
        shadowOffset: { width: -2, height: 4 },
        shadowOpacity: 0.2,
        shadowRadius: 3,
        elevation: 3,
    },

    goldCard: {
        backgroundColor: mainColors.gold,
        fontWeight: '700',
        fontSize: 34,
        alignItems: "center"
    },
    titleText: {
        fontSize: 20,
        fontWeight: 'bold',
        color: "black"
    },
    card: {
        borderRadius: 12,
        padding: 20
    },
});

export default SetsOfCategory;